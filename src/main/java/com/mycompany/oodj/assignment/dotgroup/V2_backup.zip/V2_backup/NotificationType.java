package com.mycompany.oodj.assignment.dotgroup;

public enum NotificationType {
    ISSUES,
    ACKNOWLEDGEMENTS,
    SUCCESS,
    FIXED
}
