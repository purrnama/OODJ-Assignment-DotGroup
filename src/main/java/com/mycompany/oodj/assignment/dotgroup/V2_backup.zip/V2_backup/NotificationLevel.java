package com.mycompany.oodj.assignment.dotgroup;

public enum NotificationLevel {
    LOW,
    MEDIUM, 
    HIGH
}
