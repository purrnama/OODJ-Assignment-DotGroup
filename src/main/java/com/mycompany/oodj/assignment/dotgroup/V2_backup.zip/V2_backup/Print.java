//package com.mycompany.oodj.assignment.dotgroup;
//
//public class Print<T> {
//    private void printLine(T value) {
//        System.out.println(value);
//    }
//
//    private void print(T value) {
//        System.out.print(value);
//    }
//
//    private void printf(T value) {
//        System.out.printf("%s", value);
//    } 
//    
//    public static void print() {
//        print(value);
//    }
//    
//    private T value;
//}
