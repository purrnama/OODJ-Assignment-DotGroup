package com.mycompany.oodj.assignment.dotgroup;

public enum IssueStatusCustomer {
	IN_PROGRESS,
	DONE,
	CLOSED, 
	COMPLETED,
}
